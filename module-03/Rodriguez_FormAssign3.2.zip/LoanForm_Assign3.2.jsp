<!-- 
 Carolina Rodriguez
 CSD-430
 Assignment 3.2
 
 Resources: 
 
Colbert, M. (2015 Sept 25). Creating a simple .jsp web form. [Video]. YouTube. https://www.youtube.com/watch?v=KJD3UzwW5eU
OpenAI. (2026). ChatGPT [Large language model]. https://chat.openai.com/
-->



<%@ page language="java" contentType="text/html; charset=UTF-8"%>

<!DOCTYPE html>
<html>
<head>
    <title>Loan Application Form</title>
</head>
<body>

<h2>Loan Application Form</h2>
<p>Please fill out all required fields below.</p>

<form action="results.jsp" method="post">

    <!-- First and Last input -->
    First Name: <input type="text" name="firstName"><br><br>

    Last Name: <input type="text" name="lastName"><br><br>

    <!-- Email input -->
    Date of Birth (MM/DD/YYYY): <input type="text" name="dateOfBirth"><br><br>

    <!-- Social Input -->
    Last 4 Digits of SSN: <input type="text" name="lastFourSSN"><br><br>

    <!-- Number input -->
    Annual Income: <input type="number" name="annualIncome" min="25000" max="85000"> <br><br> <!--Set min and max values-->
 
    <!-- Buttons -->
    <input type="submit" value="Submit">
    <input type="reset" value="Clear Form">


</form>

</body>
</html>