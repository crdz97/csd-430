<!--
Carolina Rodriguez
CSD-430
Assignment 3.2
-->

<%@ page language="java" contentType="text/html; charset=UTF-8"%>

<%
/* 
* Data
*/

    String firstName = request.getParameter("firstName");
    String lastName = request.getParameter("lastName");
    String dateOfBirth = request.getParameter("dateOfBirth");
    String lastFourSSN = request.getParameter("lastFourSSN");
    String annualIncome = request.getParameter("annualIncome");

%>

<!DOCTYPE html>
<html>
<head>
    <title>Loan Application Results</title>
</head>
<body>

<h2>Loan Application Summary</h2>

<table border="1" cellpadding="10">

    <tr>
        <td>First Name:</td>
        <td><%= firstName %></td>
    </tr>

    <tr>
        <td>Last Name:</td>
        <td><%= lastName %></td>
    </tr>

    <tr>
        <td>Date of Birth(MM/DD/YYYY):</td>
        <td><%= dateOfBirth %></td>
    </tr>

    <tr>
        <td>Last 4 SSN:</td>
        <td><%= lastFourSSN %></td>
    </tr>

    <tr>
        <td>Annual Income:</td>
        <td><%= annualIncome %></td>
    </tr>


</table>

<br>

</body>
</html>