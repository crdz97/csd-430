
<%-- 
Carolina Rodriguez
Assignment 1.3
 Hello World Demo
 --%>

<html>
<head>
    <title>My First JSP</title>
</head>
<body>

<h1>Hello from JSP!</h1>

<%
    String name = "Carolina";
    out.println("<p>Welcome " + name + "!</p>");
%>

</body>
</html>