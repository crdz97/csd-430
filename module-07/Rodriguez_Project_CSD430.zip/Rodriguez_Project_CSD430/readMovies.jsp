<!-- Carolina Rodriguez
CSD-430
Assignment 6.2 JavaBeans, SQL Database and Java dropdown menu

Resources:
GeeksforGeeks. (2025, July 23). Dynamic dropdown from database using Spring Boot. https://www.geeksforgeeks.org/java/dynamic-dropdown-from-database-using-spring-boot/
Oracle. (n.d.). What is a JSP page? The Java EE 5 Tutorial. https://docs.oracle.com/javaee/5/tutorial/doc/bnagy.html
OpenAI. (2026). ChatGPT (June 14 version) [Large language model]. https://chat.openai.com/
Stack Overflow. (2014, June 5). How to dynamically populate the drop down list in my JSP page from the database. https://stackoverflow.com/questions/24074221/how-to-dynamically-populate-the-drop-down-list-in-my-jsp-page-from-the-database
-->
<%@ page import="java.util.ArrayList" %> <!-- Import the ArrayList class -->
<%@ page import="beans.Movie" %> <!-- Import the Movie class -->
<%@ page import="beans.MovieBean" %> <!-- Import the MovieBean class -->
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<jsp:useBean id="movieBean" class="beans.MovieBean" scope="page" /> <!-- Use MovieBean -->

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <link rel="stylesheet" href="style1.css">

    <title>Carolina's Movie Database</title>
</head>
<body>
<div class="container">
    <h1>Carolina's Movie Database</h1>

    <p>
        This page displays movie records from the CSD430 database using a JavaBean.
        Select a movie ID from the dropdown menu to view the full movie record.
    </p>

    <h2>Select a Movie Record</h2>

    <form method="post" action="readMovies.jsp"> <!-- Form to retrieve movies-->
        <label for="movie_id">Movie ID:</label>

        <select name="movie_id" id="movie_id">

            <%
                ArrayList<Integer> movieIds = movieBean.getMovieIds();

                if (movieIds.size() == 0) {
            %>
                    <option>No movie IDs found</option> <!-- Display message if no movie IDs are found -->
            <%
                } else {
                    for (Integer id : movieIds) {
            %>
                        <option value="<%= id %>"><%= id %></option> <!-- Display each movie ID as an option in the dropdown menu -->
            <%
                    }
                }
            %>
</select>
        </select>

        <input type="submit" value="View Movie">
    </form>

    <br>

    <%
        String selectedMovieId = request.getParameter("movie_id");

        if (selectedMovieId != null) {
            int movieId = Integer.parseInt(selectedMovieId); 
            Movie movie = movieBean.getMovieById(movieId);

            if (movie != null) {
    %>

    <h2>Selected Movie Record</h2>

    <table border="1">
        <thead>
            <tr>
                <th>Movie ID</th>
                <th>Movie Title</th>
                <th>Main Character</th>
                <th>Genre</th>
                <th>Rating</th>
                <th>Release Year</th>
            </tr>
        </thead>

        <tbody>
            <tr>
                <td><%= movie.getMovieId() %></td>
                <td><%= movie.getMovieTitle() %></td>
                <td><%= movie.getMainCharacter() %></td>
                <td><%= movie.getGenre() %></td>
                <td><%= movie.getRating() %></td>
                <td><%= movie.getReleaseYear() %></td>
            </tr>
        </tbody>
    </table>

    <%
            } else {
    %>

    <p>No movie record was found for the selected ID.</p>

    <%
            }
        }
    %>

    <br>

    <p>
        <a href="index.jsp">Return to Index</a>
    </p>
</div>
</body>
</html>