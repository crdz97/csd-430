<!--
Carolina Rodriguez
CSD430
Project Part 2 - Add and display movie records

Resources:
GeeksforGeeks. (2025, July 23). Java program to insert details in a table using JDBC. https://www.geeksforgeeks.org/java/java-program-to-insert-details-in-a-table-using-jdbc/
GeeksforGeeks. (2025, July 23). Dynamic dropdown from database using Spring Boot. https://www.geeksforgeeks.org/java/dynamic-dropdown-from-database-using-spring-boot/
Oracle. (n.d.). What is a JSP page? The Java EE 5 Tutorial. https://docs.oracle.com/javaee/5/tutorial/doc/bnagy.html
OpenAI. (2026). ChatGPT. [Large language model]. https://chat.openai.com/
Saptarshi, C. (2017, November 25). Inserting data into database Java JDBC [Online forum post]. Stack Overflow. https://stackoverflow.com/questions/47488481/inserting-data-into-database-java-jdbc
Stack Overflow. (2014, June 5). How to dynamically populate the drop down list in my JSP page from the database. https://stackoverflow.com/questions/24074221/how-to-dynamically-populate-the-drop-down-list-in-my-jsp-page-from-the-database
-->
<%@ page import="java.util.ArrayList" %>
<%@ page import="beans.Movie" %>
<%@ page import="beans.MovieBean" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<jsp:useBean id="movieBean" class="beans.MovieBean" scope="page" />

<%
    // Display a status message after the form is processed.
    String message = "";
    boolean formSubmitted = "POST".equalsIgnoreCase(request.getMethod());

    if (formSubmitted) {
        request.setCharacterEncoding("UTF-8");

        String movieTitle = request.getParameter("movie_title");
        String mainCharacter = request.getParameter("main_character");
        String genre = request.getParameter("genre");
        String rating = request.getParameter("rating");
        String releaseYearValue = request.getParameter("release_year");

        try {
            int releaseYear = Integer.parseInt(releaseYearValue);

            boolean added = movieBean.addMovie(
                movieTitle.trim(),
                mainCharacter.trim(),
                genre.trim(),
                rating.trim(),
                releaseYear
            );

            if (added) {
                message = "The new movie record was added successfully. Its Movie ID was generated automatically.";
            } else {
                message = "The movie record could not be added. Check the database connection and server log.";
            }
        } catch (Exception e) {
            message = "Please enter valid information in every field.";
        }
    }

    ArrayList<Movie> movies = movieBean.getAllMovies();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add a Movie Record</title>
    <link rel="stylesheet" href="style1.css">
</head>
<body>
<div class="container">
    <h1>Add a Movie Record</h1>

    <p>
        Enter the information for a new movie below. After filling out the form, click the "Add Movie" button to submit the information. The new movie record will be added to the database, and you will see a confirmation message if the addition was successful.
    </p>

    <h2>Movie Entry Form</h2>

    <form method="post" action="addMovie.jsp" class="movie-form">
        <div class="form-group">
            <label for="movie_title">Movie Title:</label>
            <input type="text" id="movie_title" name="movie_title" maxlength="100" required>
        </div>

        <div class="form-group">
            <label for="main_character">Main Character:</label>
            <input type="text" id="main_character" name="main_character" maxlength="100" required>
        </div>

        <div class="form-group">
            <label for="genre">Genre:</label>
            <input type="text" id="genre" name="genre" maxlength="50" required>
        </div>

        <div class="form-group">
            <label for="rating">Rating:</label>
            <select id="rating" name="rating" required>
                <option value="">Select a rating</option>
                <option value="G">G</option>
                <option value="PG">PG</option>
                <option value="PG-13">PG-13</option>
                <option value="R">R</option>
                <option value="NR">NR</option>
            </select>
        </div>

        <div class="form-group">
            <label for="release_year">Release Year:</label>
            <input type="number" id="release_year" name="release_year"
                   min="1888" max="2100" required>
        </div>

        <input type="submit" value="Add Movie">
    </form>

    <% if (!message.isEmpty()) { %>
        <p class="status-message"><%= message %></p>
    <% } %>

    <h2>All Movie Records</h2>


    <table>
        <thead>
        <tr>
            <th>Movie ID</th>
            <th>Movie Title</th>
            <th>Main Character</th>
            <th>Genre</th>
            <th>Rating</th>
            <th>Release Year</th>
        </tr>
        </thead>
        <tbody>
        <% if (movies.isEmpty()) { %>
            <tr>
                <td colspan="6">No movie records were found.</td>
            </tr>
        <% } else { %>
            <% for (Movie movie : movies) { %>
                <tr>
                    <td><%= movie.getMovieId() %></td>
                    <td><%= movie.getMovieTitle() %></td>
                    <td><%= movie.getMainCharacter() %></td>
                    <td><%= movie.getGenre() %></td>
                    <td><%= movie.getRating() %></td>
                    <td><%= movie.getReleaseYear() %></td>
                </tr>
            <% } %>
        <% } %>
        </tbody>
    </table>

   <p class="footer-link" style="text-align: left;">
    <a href="index.jsp">Return to Index</a>
</p>
</div>
</body>
</html>
