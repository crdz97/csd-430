--Carolina Rodriguez
---CSD430
--SQL Movie Database


CREATE DATABASE IF NOT EXISTS CSD430;

USE CSD430;

CREATE USER IF NOT EXISTS 'student1'@'localhost' IDENTIFIED BY 'pass';

--student1@localhost 
GRANT ALL PRIVILEGES ON CSD430.* TO 'student1'@'localhost';

FLUSH PRIVILEGES;

DROP TABLE IF EXISTS carolina_movies_data;

CREATE TABLE carolina_movies_data (
    movie_id INT AUTO_INCREMENT PRIMARY KEY,
    movie_title VARCHAR(100) NOT NULL,
    main_character VARCHAR(100) NOT NULL,
    genre VARCHAR(50) NOT NULL,
    rating VARCHAR(10) NOT NULL,
    release_year INT NOT NULL
);

INSERT INTO carolina_movies_data 
(movie_title, main_character, genre, rating, release_year)
VALUES
('The Help', 'Aibileen Clark', 'Drama', 'PG-13', 2011),
('The Notebook', 'Noah Calhoun', 'Romance', 'PG-13', 2004),
('Inception', 'Dom Cobb', 'Sci-Fi', 'PG-13', 2010),
('Interstellar', 'Cooper', 'Sci-Fi', 'PG-13', 2014),
('Me Before You', 'Louisa Clark', 'Romance', 'PG-13', 2016),
('Spider-Man', 'Peter Parker', 'Action', 'PG-13', 2002),
('Obsession', 'Bear', 'Horror', 'R', 2026),
('The Lake House', 'Alex Wyler', 'Romance', 'PG', 2006),
('The Proposal', 'Margaret Tate', 'Comedy', 'PG-13', 2009),
('The Vow', 'Paige Collins', 'Romance', 'PG-13', 2012);
