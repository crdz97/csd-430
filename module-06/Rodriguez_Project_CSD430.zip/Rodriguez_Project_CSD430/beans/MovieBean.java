//Carolina Rodriguez
//CSD430
//MovieBean.java
// This class is used to retrieve movie records from the database
package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;

public class MovieBean {

    private final String url = "jdbc:mysql://localhost:3306/CSD430";
    private final String username = "student1";
    private final String password = "pass";

    public MovieBean() {
    }

    // This method gets all movie_id values for the dropdown menu
    public ArrayList<Integer> getMovieIds() {
        ArrayList<Integer> movieIds = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load the MySQL JDBC driver

            Connection connection = DriverManager.getConnection(url, username, password);
            Statement statement = connection.createStatement();

            String sql = "SELECT movie_id FROM carolina_movies_data ORDER BY movie_id";

            ResultSet resultSet = statement.executeQuery(sql);

            while (resultSet.next()) {
                movieIds.add(resultSet.getInt("movie_id"));
            }

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return movieIds;
    }

    // This method gets one movie record based on the selected movie_id
    public Movie getMovieById(int movieId) {
        Movie movie = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); // Load the MySQL JDBC driver

            Connection connection = DriverManager.getConnection(url, username, password);

            String sql = "SELECT movie_id, movie_title, main_character, genre, rating, release_year "
                       + "FROM carolina_movies_data WHERE movie_id = ?";

            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setInt(1, movieId);

            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                movie = new Movie();

                movie.setMovieId(resultSet.getInt("movie_id"));
                movie.setMovieTitle(resultSet.getString("movie_title"));
                movie.setMainCharacter(resultSet.getString("main_character"));
                movie.setGenre(resultSet.getString("genre"));
                movie.setRating(resultSet.getString("rating"));
                movie.setReleaseYear(resultSet.getInt("release_year"));
            }

            resultSet.close();
            statement.close();
            connection.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return movie;
    }
}
