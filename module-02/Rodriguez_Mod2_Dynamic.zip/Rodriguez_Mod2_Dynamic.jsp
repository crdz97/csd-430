<!-- Carolina Rodriguez
 CSD-430
 Assignment 2: Dynamic JSP Page
 
 Resources: 
 Community. (n.d.). Creating rows of a table in a for loop in JSP. Stack Overflow. https://stackoverflow.com/questions/5645708/creating-rows-of-a-table-in-a-for-loop-in-jsp
 GeeksforGeeks. (2025, Jul 23). Java program to get last modification date of a file. https://www.geeksforgeeks.org/java/java-program-to-get-last-modification-date-of-a-file/
 OpenAI. (2026). ChatGPT (June 14 version) [Large language model]. https://chat.openai.com/
 -->


<%@ page language="java" contentType="text/html; charset=UTF-8" %>

<!DOCTYPE html>
<html lang="en">

<head>
    <title>Favorite Movies</title>

    <meta name="author" content="Caro">
    <meta name="description" content="A dynamic JSP page displaying my favorite movies">
    <meta charset="UTF-8">

    <!-- CSS file-->
    <link rel="stylesheet" href="Rodriguez_Mod2_Dynamic.css">

</head>

<body>

<header>
    <h1>Top 5 Favorite Movies</h1>
</header>

<%
    java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("MMMM dd, yyyy hh:mm a");
%>

<p>Page generated on: <%= sdf.format(new java.util.Date()) %> </p>

<div id="container">

    <div class="card">

        <div class="card-title">
            My Favorite Movies
        </div>

        <div class="card-content">

            <p>
                This table displays five of my favorite movies along with 
                two main characters and my personal rating of each movie.
            </p>


            <%
                /*
                 * Java Scriptlet:
                 * This array stores the movie information that will
                 * be displayed in the HTML table.
                 *
                 * Fields:
                 * 1. Movie Name
                 * 2. Main Characters
                 * 3. Rating
                 */

                String[][] movies = {
                    {"The Help", "Eugenia 'Skeeter' and Aibileen Clark", "5/5"},
                    {"The Notebook", "Noah Calhoun and Allie Hamilton", "5/5"},
                    {"Inception", "Cobb and Arthur", "5/5"},
                    {"Interstellar", "Cooper and Murph", "5/5"},
                    {"Me Before You", "Louisa Clark and Will Traynor", "4/5"}
                };
            %>


            <table id="movies">

                <thead>
                    <tr>
                        <th>Movie Name</th>
                        <th>Two Characters</th>
                        <th>Rating</th>
                    </tr>
                </thead>


                <tbody>

                    <%
                        /*
                         * Loop through the Java array and use JSP scriptlet to dynamically
                         * create each table row.
                         */

                        for(int i = 0; i < movies.length; i++) {
                    %>

                    <tr>
                        <td><%= movies[i][0] %></td>
                        <td><%= movies[i][1] %></td>
                        <td><%= movies[i][2] %></td>
                    </tr>

                    <%
                        }
                    %>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>
