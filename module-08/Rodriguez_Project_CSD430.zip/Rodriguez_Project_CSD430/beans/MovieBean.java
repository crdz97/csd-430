// Carolina Rodriguez
// CSD430
// MovieBean.java
// Used to add, retrieve and update movie records from the database
package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

public class MovieBean {

    private final String url = "jdbc:mysql://localhost:3306/CSD430";
    private final String username = "student1";
    private final String password = "pass";

    public MovieBean() {
    }

    // Opens and returns a connection to the CSD430 database.
    private Connection getConnection() throws Exception {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(url, username, password);
    }

    // Returns every movie ID for the dropdown menu on the read page.
    public ArrayList<Integer> getMovieIds() {
        ArrayList<Integer> movieIds = new ArrayList<>();
        String sql = "SELECT movie_id FROM carolina_movies_data ORDER BY movie_id";

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                movieIds.add(resultSet.getInt("movie_id"));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return movieIds;
    }

    // Returns one movie selected by its automatically generated key value.
    public Movie getMovieById(int movieId) {
        Movie movie = null;
        String sql = "SELECT movie_id, movie_title, main_character, genre, rating, release_year "
                   + "FROM carolina_movies_data WHERE movie_id = ?";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setInt(1, movieId);

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    movie = createMovieFromResultSet(resultSet);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return movie;
    }

    // Adds a new movie. The database generates movie_id using AUTO_INCREMENT.
    public boolean addMovie(String movieTitle, String mainCharacter,
                            String genre, String rating, int releaseYear) {
        String sql = "INSERT INTO carolina_movies_data "
                   + "(movie_title, main_character, genre, rating, release_year) "
                   + "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, movieTitle);
            statement.setString(2, mainCharacter);
            statement.setString(3, genre);
            statement.setString(4, rating);
            statement.setInt(5, releaseYear);

            return statement.executeUpdate() == 1;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Returns all movie records for display after a new record is submitted.
    public ArrayList<Movie> getAllMovies() {
        ArrayList<Movie> movies = new ArrayList<>();
        String sql = "SELECT movie_id, movie_title, main_character, genre, rating, release_year "
                   + "FROM carolina_movies_data ORDER BY movie_id";

        try (Connection connection = getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            while (resultSet.next()) {
                movies.add(createMovieFromResultSet(resultSet));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return movies;
    }

    // Creates a Movie object from the current ResultSet row.
    private Movie createMovieFromResultSet(ResultSet resultSet) throws Exception {
        Movie movie = new Movie();
        movie.setMovieId(resultSet.getInt("movie_id"));
        movie.setMovieTitle(resultSet.getString("movie_title"));
        movie.setMainCharacter(resultSet.getString("main_character"));
        movie.setGenre(resultSet.getString("genre"));
        movie.setRating(resultSet.getString("rating"));
        movie.setReleaseYear(resultSet.getInt("release_year"));
        return movie;
    }

    // Updates an existing movie record using its movie ID.
    public boolean updateMovie(Movie movie) {
        String sql = "UPDATE carolina_movies_data "
                + "SET movie_title = ?, "
                + "main_character = ?, "
                + "genre = ?, "
                + "rating = ?, "
                + "release_year = ? "
                + "WHERE movie_id = ?";

        try (Connection connection = getConnection();
            PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, movie.getMovieTitle());
            statement.setString(2, movie.getMainCharacter());
            statement.setString(3, movie.getGenre());
            statement.setString(4, movie.getRating());
            statement.setInt(5, movie.getReleaseYear());
            statement.setInt(6, movie.getMovieId());

            return statement.executeUpdate() == 1;

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
