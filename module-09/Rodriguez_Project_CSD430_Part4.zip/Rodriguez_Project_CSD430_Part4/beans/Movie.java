//Carolina Rodriguez
//CSD430
//Movie.java
// This class represents a movie record with its attributes

package beans;

import java.io.Serializable;

public class Movie implements Serializable {
    private static final long serialVersionUID = 1L;

    private int movieId;
    private String movieTitle;
    private String mainCharacter;
    private String genre;
    private String rating;
    private int releaseYear;

    //Public no-argument constructor
    public Movie() {
    }
   //Parameterized constructor 
    public Movie(int movieId, String movieTitle, String mainCharacter, String genre, String rating, int releaseYear) {
        this.movieId = movieId;
        this.movieTitle = movieTitle;
        this.mainCharacter = mainCharacter;
        this.genre = genre;
        this.rating = rating;
        this.releaseYear = releaseYear;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieTitle() {
        return movieTitle;
    }

    public void setMovieTitle(String movieTitle) {
        this.movieTitle = movieTitle;
    }

    public String getMainCharacter() {
        return mainCharacter;
    }

    public void setMainCharacter(String mainCharacter) {
        this.mainCharacter = mainCharacter;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }
}
