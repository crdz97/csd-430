<%--
    Carolina Rodriguez
    CSD-430
    Project Part 3

    updateMovieResult.jsp

    This page updates the selected movie record and
    displays the updated record in a table.
--%>

<%@ page import="beans.Movie" %>
<%@ page import="beans.MovieBean" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<jsp:useBean id="movieBean"
             class="beans.MovieBean"
             scope="page" />

<%
    Movie updatedMovie = null;
    String errorMessage = null;
    boolean updateSuccessful = false;

    // Retrieve submitted form values.
    String movieIdParameter = request.getParameter("movieId");
    String movieTitle = request.getParameter("movieTitle");
    String mainCharacter = request.getParameter("mainCharacter");
    String genre = request.getParameter("genre");
    String rating = request.getParameter("rating");
    String releaseYearParameter = request.getParameter("releaseYear");

    // Check that all required values were submitted.
    if (movieIdParameter == null || movieIdParameter.trim().isEmpty()
            || movieTitle == null || movieTitle.trim().isEmpty()
            || mainCharacter == null || mainCharacter.trim().isEmpty()
            || genre == null || genre.trim().isEmpty()
            || rating == null || rating.trim().isEmpty()
            || releaseYearParameter == null || releaseYearParameter.trim().isEmpty()) {

        errorMessage = "All movie fields are required.";

    } else {
        try {
            int movieId = Integer.parseInt(movieIdParameter);
            int releaseYear = Integer.parseInt(releaseYearParameter);

            // Create a Movie object with the updated values.
            Movie movie = new Movie();
            movie.setMovieId(movieId);
            movie.setMovieTitle(movieTitle.trim());
            movie.setMainCharacter(mainCharacter.trim());
            movie.setGenre(genre.trim());
            movie.setRating(rating.trim());
            movie.setReleaseYear(releaseYear);

            // Update the database record.
            updateSuccessful = movieBean.updateMovie(movie);

            if (updateSuccessful) {
                updatedMovie = movieBean.getMovieById(movieId);

                if (updatedMovie == null) {
                    errorMessage =
                        "The movie was updated, but the record could not be retrieved.";
                }
            } else {
                errorMessage = "The movie record could not be updated.";
            }

        } catch (NumberFormatException e) {
            errorMessage = "The movie ID and release year must be valid numbers.";
        }
    }
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <title>Updated Movie Record</title>

    <link rel="stylesheet" href="style1.css">
</head>

<body>

<div class="container">

    <h1>Updated Movie Record</h1>
    <div>
    <p>Movie ID: <%= movieIdParameter %></p>
    <p>Movie Title: <%= movieTitle %></p>
    <p>Main Character: <%= mainCharacter %></p>
    <p>Genre: <%= genre %></p>
    <p>Rating: <%= rating %></p>
    <p>Release Year: <%= releaseYearParameter %></p>
</div>


    <% if (errorMessage != null) { %>

        <p class="error-message">
            <%= errorMessage %>
        </p>

    <% } else if (updateSuccessful && updatedMovie != null) { %>

        <p class="success-message">
            The movie record was updated successfully.
        </p>

        <div class="table-wrapper">

            <table>

                <thead>

                    <th>Movie ID (INT)</th>
                    <th>Movie Title (VARCHAR)</th>
                    <th>Main Character (VARCHAR)</th>
                    <th>Genre (VARCHAR)</th>
                    <th>Rating (VARCHAR)</th>
                    <th>Release Year (INT)</th>

                </thead>

                <tbody>

                    <tr>
                        <td><%= updatedMovie.getMovieId() %></td>
                        <td><%= updatedMovie.getMovieTitle() %></td>
                        <td><%= updatedMovie.getMainCharacter() %></td>
                        <td><%= updatedMovie.getGenre() %></td>
                        <td><%= updatedMovie.getRating() %></td>
                        <td><%= updatedMovie.getReleaseYear() %></td>
                    </tr>

                </tbody>

            </table>

        </div>

    <% } %>


    <p class="footer-link">
        <a href="updateMovie.jsp">Update Another Movie</a>
    </p>

    <p class="footer-link">
        <a href="index.jsp">Return to Index</a>
    </p>

</div>

</body>

</html>