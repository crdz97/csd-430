<!--
Carolina Rodriguez
CSD-430
Project Part 3
updateMovie.jsp

This page displays a movie title dropdown and retrieves the selected record for editing.

Resources:     
    GeeksforGeeks. (2025, August 25). Update and delete operations using JDBC in Java. [https://www.geeksforgeeks.org/java/update-and-delete-operations-using-jdbc-in-java/](https://www.geeksforgeeks.org/java/update-and-delete-operations-using-jdbc-in-java/)
    Hall, M. (n.d.). JavaServer Pages (JSP) 1.0. Université Côte d’Azur. https://users.polytech.unice.fr/~buffa/cours/internet/POLYS/servlets/Servlet-Tutorial-JSP.html#Section8
    Oracle. (n.d.). Updating data. In Oracle Database Express Edition 2 Day + Java Developer’s Guide. Retrieved July 16, 2026, from https://docs.oracle.com/cd/E17781_01/appdev.112/e18805/upddata.htm#BGBHCCIH
    OpenAI. (2026). ChatGPT (June 14 version) [Large language model]. https://chat.openai.com/
    SheCodes. (n.d.). Coding questions about JavaScript. SheCodes Athena. https://www.shecodes.io/athena?topic=JavaScript#questions
-->

<%@ page import="java.util.ArrayList" %>
<%@ page import="beans.Movie" %>
<%@ page import="beans.MovieBean" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<jsp:useBean id="movieBean"
             class="beans.MovieBean"
             scope="page" />

<%
    // Retrieve all movie records for the dropdown menu.
    ArrayList<Movie> movies = movieBean.getAllMovies();

    Movie selectedMovie = null;
    String errorMessage = null;

    // Retrieve the selected movie ID after the dropdown is submitted.
    String movieIdParameter = request.getParameter("movieId");

    if (movieIdParameter != null && !movieIdParameter.trim().isEmpty()) {
        try {
            int movieId = Integer.parseInt(movieIdParameter);

            // Retrieve the complete selected movie record.
            selectedMovie = movieBean.getMovieById(movieId);

            if (selectedMovie == null) {
                errorMessage = "The selected movie record could not be found.";
            }

        } catch (NumberFormatException e) {
            errorMessage = "The selected movie ID is invalid.";
        }
    }
%>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Update Movie Record</title>
    <link rel="stylesheet" href="style1.css">
</head>

<body>

<div class="container">

    <h1>Update Movie Record</h1>

    <p>Select a movie from the dropdown menu.</p>

    <% if (movies != null && !movies.isEmpty()) { %>

        <form action="updateMovie.jsp" method="post">

            <div class="form-group">
                <label for="movieId">Select Movie:</label>

                <select name="movieId" id="movieId" required>
                    <option value="">Select a Movie</option>

                    <% for (Movie movie : movies) { %>

                        <option value="<%= movie.getMovieId() %>"
                            <%= movieIdParameter != null
                                && movieIdParameter.equals(
                                    String.valueOf(movie.getMovieId()))
                                ? "selected" : "" %>>

                             <%= movie.getMovieId() %> - <%= movie.getMovieTitle() %>
                        </option>

                    <% } %>

                </select>
            </div>

            <div class="form-buttons">
                <input type="submit" value="Select Movie">
            </div>

        </form>

    <% } else { %>

        <p class="error-message">
            No movie records were found in the database.
        </p>

    <% } %>

    <% if (errorMessage != null) { %>

        <p class="error-message">
            <%= errorMessage %>
        </p>

    <% } %>

    <% if (selectedMovie != null) { %>

        <hr>

        <h2>Edit Selected Movie</h2>

        <p>
            Update the movie information below. The movie ID cannot be changed.
        </p>

        <form action="<%= request.getContextPath() %>/Rodriguez_Project_CSD430/updateMovieResult.jsp"
              method="post">

            <div class="form-group">
                <label>Movie ID:</label>

                <span class="read-only-value">
                    <%= selectedMovie.getMovieId() %>
                </span>

                <input type="hidden"
                       name="movieId"
                       value="<%= selectedMovie.getMovieId() %>">
            </div>

            <div class="form-group">
                <label for="movieTitle">Movie Title:</label>

                <input type="text"
                       id="movieTitle"
                       name="movieTitle"
                       value="<%= selectedMovie.getMovieTitle() %>"
                       required>
            </div>

            <div class="form-group">
                <label for="mainCharacter">Main Character:</label>

                <input type="text"
                       id="mainCharacter"
                       name="mainCharacter"
                       value="<%= selectedMovie.getMainCharacter() %>"
                       required>
            </div>

            <div class="form-group">
                <label for="genre">Genre:</label>

                <input type="text"
                       id="genre"
                       name="genre"
                       value="<%= selectedMovie.getGenre() %>"
                       required>
            </div>

            <div class="form-group">
                <label for="rating">Rating:</label>

                <input type="text"
                       id="rating"
                       name="rating"
                       value="<%= selectedMovie.getRating() %>"
                       required>
            </div>

            <div class="form-group">
                <label for="releaseYear">Release Year:</label>

                <input type="number"
                       id="releaseYear"
                       name="releaseYear"
                       value="<%= selectedMovie.getReleaseYear() %>"
                       min="1888"
                       max="2100"
                       required>
            </div>

            <div class="form-buttons">
                <input type="submit" value="Update Movie">
            </div>

        </form>

    <% } %>

    <p class="footer-link">
        <a href="index.jsp">Return to Index</a>
    </p>

</div>

</body>
</html>