<!--
Carolina Rodriguez
CSD-430
Project Part 4
Delete movie records using a JavaBean and JSP

Resources:
GeeksforGeeks. (2026, Jul 6). Servlet—CRUD.https://www.geeksforgeeks.org/java/servlet-crud/
Mallikarjun, V. (2025, May 24). Class -12: Delete Student Record Using JSP & MySQL | Remove Data from Database (Part 12). YouTube. https://www.youtube.com/watch?v=Qv3rhHwv7pg&t=386s 
OpenAI. (2026). ChatGPT. [Large language model]. https://chat.openai.com/
-->

<%@ page import="java.util.ArrayList" %>
<%@ page import="beans.Movie" %>
<%@ page import="beans.MovieBean" %>
<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>

<jsp:useBean id="movieBean" class="beans.MovieBean" scope="page" />

<%
    /*
     * When a movie ID is submitted, delete that movie record.
     */
    String selectedMovieId = request.getParameter("movie_id");
    String message = "";

    if (selectedMovieId != null && !selectedMovieId.trim().isEmpty()) {
        try {
            int movieId = Integer.parseInt(selectedMovieId);

            boolean deleted = movieBean.deleteMovie(movieId);

            if (deleted) {
                message = "Movie record " + movieId
                        + " was successfully deleted.";
            } else {
                message = "The selected movie record could not be deleted.";
            }
        } catch (NumberFormatException e) {
            message = "The selected movie ID was not valid.";
        }
    }

    /*
     * Retrieve the current records after the deletion.
     * These lists will automatically reflect any deleted records.
     */
    ArrayList<Movie> movies = movieBean.getAllMovies();
    ArrayList<Integer> movieIds = movieBean.getMovieIds();
%>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <title>Delete Movie Records</title>

    <link rel="stylesheet" href="style1.css">
</head>

<body>
<div class="container">

    <h1>Carolina's Movie Database</h1>

    <p>
        This page displays all records stored in the movie
        database. Select a movie ID from the dropdown menu to delete
        the record.
    </p>

    <%
        if (!message.isEmpty()) {
    %>
        <p><strong><%= message %></strong></p>
    <%
        }
    %>

    <h2>Current Movie Records</h2>

    <!--
        The table is always displayed. If all records are deleted,
        the table header remains visible and the table body is empty.
    -->
    <table border="1">
        <thead>
            <tr>
                <th>Movie ID</th>
                <th>Movie Title</th>
                <th>Main Character</th>
                <th>Genre</th>
                <th>Rating</th>
                <th>Release Year</th>
            </tr>
        </thead>

        <tbody>
            <%
                for (Movie movie : movies) {
            %>
                <tr>
                    <td><%= movie.getMovieId() %></td>
                    <td><%= movie.getMovieTitle() %></td>
                    <td><%= movie.getMainCharacter() %></td>
                    <td><%= movie.getGenre() %></td>
                    <td><%= movie.getRating() %></td>
                    <td><%= movie.getReleaseYear() %></td>
                </tr>
            <%
                }
            %>
        </tbody>
    </table>

    <br>

    <h2>Delete a Movie Record</h2>

    <%
        if (!movieIds.isEmpty()) {
    %>

        <form method="post" action="deleteMovie.jsp">
            <label for="movie_id">
                Select Movie ID:
            </label>

            <select name="movie_id"
                    id="movie_id"
                    required>

                <option value="" selected disabled>
                    Select a movie ID
                </option>

                <%
                    for (Integer movieId : movieIds) {
                %>
                    <option value="<%= movieId %>">
                        <%= movieId %>
                    </option>
                <%
                    }
                %>
            </select>

            <input type="submit"
                   value="Delete Movie"
                   onclick="return confirm(
                       'Are you sure you want to delete this movie record?'
                   );">
        </form>

    <%
        } else {
    %>

        <p>There are no remaining movie records to delete.</p>

    <%
        }
    %>

    <br>

    <p>
        <a href="index.jsp">Return to Index</a>
    </p>

</div>
</body>
</html>