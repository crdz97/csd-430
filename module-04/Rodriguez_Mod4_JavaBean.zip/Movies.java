//Carolina Rodriguez
//CSD-430
//Module 4: JavaClass and JavaBean

//Resources: 
// GeeksforGeeks. (2026, June 1). Serialization and deserialization in Java. https://www.geeksforgeeks.org/java/serialization-and-deserialization-in-java/


package beans; // Package declaration for the Movies class
import java.io.Serializable;

public class Movies implements Serializable {

    private static final long serialVersionUID = 1L; // Unique identifier for serialization

    private String movieName; 
    private String mainCharacters;
    private String rating;
    private String genre;
    private int releaseYear; // Changed from String to int for releaseYear

    public Movies() {
    }
// Parameterized constructor to initialize all fields
    public Movies(String movieName, String mainCharacters, String rating, String genre, int releaseYear) {
        this.movieName = movieName;
        this.mainCharacters = mainCharacters;
        this.rating = rating;
        this.genre = genre;
        this.releaseYear = releaseYear;
    }
// Getters and Setters for each field
    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getMainCharacters() {
        return mainCharacters;
    }

    public void setMainCharacters(String mainCharacters) {
        this.mainCharacters = mainCharacters;
    }

    public String getRating() {
        return rating;
    }

    public void setRating(String rating) {
        this.rating = rating;
    }

    public String getGenre() {
        return genre;
    }

    public void setGenre(String genre) {
        this.genre = genre;
    }

    public int getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(int releaseYear) {
        this.releaseYear = releaseYear;
    }
}