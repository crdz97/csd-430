<!-- 
 Carolina Rodriguez
 CSD-430
 Assignment 4: JavaBean Data Display

 This JSP page uses a JavaBean to display favorite movie data. 
Resources: 
 Community. (n.d.). Creating rows of a table in a for loop in JSP. Stack Overflow. https://stackoverflow.com/questions/5645708/creating-rows-of-a-table-in-a-for-loop-in-jsp
 GeeksforGeeks. (2025, Jul 23). Java program to get last modification date of a file. https://www.geeksforgeeks.org/java/java-program-to-get-last-modification-date-of-a-file/
 OpenAI. (2026). ChatGPT (June 14 version) [Large language model]. https://chat.openai.com/
 -->


<%@ page language="java" contentType="text/html; charset=UTF-8" %>
<%@ page import="java.text.SimpleDateFormat" %>
<%@ page import="java.util.Date" %> <!-- Import the Date class for displaying the current date and time -->
<%@ page import="beans.Movies" %> <!-- Import the Movies class from the beans package -->
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Favorite Movies with JavaBean</title>

    <meta name="author" content="Caro">
    <meta name="description" content="A JSP page displaying favorite movie data from a JavaBean">
    <meta charset="UTF-8">

    <link rel="stylesheet" href="Rodriguez_Mod2_Dynamic.css">
</head>

<body>

<header>
    <h1>Top 5 Favorite Movies</h1>
</header>

<%
    SimpleDateFormat sdf = new SimpleDateFormat("MMMM dd, yyyy hh:mm a");
    /*
     * Each Movies object represents one movie record.
     * The five fields are:
     * 1. Movie Name
     * 2. Main Characters
     * 3. Rating
     * 4. Genre
     * 5. Release Year
     */

    Movies[] movies = {
        new Movies("The Help", "Eugenia 'Skeeter' and Aibileen Clark", "5/5", "Drama", 2011),
        new Movies("The Notebook", "Noah Calhoun and Allie Hamilton", "5/5", "Romance", 2004),
        new Movies("Inception", "Cobb and Arthur", "5/5", "Science Fiction", 2010),
        new Movies("Interstellar", "Cooper and Murph", "5/5", "Science Fiction", 2014),
        new Movies("Me Before You", "Louisa Clark and Will Traynor", "4/5", "Romance", 2016)
    };
%>

<p>Page generated on: <%= sdf.format(new Date()) %></p>

<div id="container">

    <div class="card">

        <div class="card-title">
            My Favorite Movies
        </div>

        <div class="card-content">

            <p>
                This page displays five of my favorite movies using a JavaBean and Movies class.
                Each movie record includes five fields: movie name, two main characters,
                my rating, genre, and release year.
            </p>

            <table id="movies">

                <thead>
                    <tr>
                        <th>Movie Name</th>
                        <th>Two Characters</th>
                        <th>Rating</th>
                        <th>Genre</th>
                        <th>Release Year</th>
                    </tr>
                </thead>

                <tbody>

                    <%
                        for (int i = 0; i < movies.length; i++) {
                    %>

                    <tr>
                        <td><%= movies[i].getMovieName() %></td>
                        <td><%= movies[i].getMainCharacters() %></td>
                        <td><%= movies[i].getRating() %></td>
                        <td><%= movies[i].getGenre() %></td>
                        <td><%= movies[i].getReleaseYear() %></td>
                    </tr>

                    <%
                        }
                    %>

                </tbody>

            </table>

        </div>

    </div>

</div>

</body>
</html>